﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;


namespace Izzyssentials
{
    public class PlaceWorker_CeilingLamp : PlaceWorker
    {
        public override AcceptanceReport AllowsPlacing(BuildableDef def, IntVec3 center, Rot4 rot, Thing thingToIgnore = null)
        {
            if (!this.Map.roofGrid.Roofed(center))
            {
                return "Must be placed under a ceiling.";
            }
       
            return true;
        }
        
    }
}
