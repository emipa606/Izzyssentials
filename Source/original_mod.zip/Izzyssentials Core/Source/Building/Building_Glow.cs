﻿using System.Collections.Generic;
using UnityEngine;
using Verse;
using RimWorld;


namespace Izzyssentials
{
    public class Building_Glow : Building //17/07/16-R
    {
        #region Variables
        private List<ThingComp> comps = new List<ThingComp>();

        public CompGlower glower;
        public CompPowerTrader powerTrader;
        public CompGlowerColour glowerColour;

        private ColorInt Blackout;
        private ColorInt LedState;

        #endregion


        #region Overrides

        public override void SpawnSetup(Map map)
        {
            base.SpawnSetup(map);

            this.glower = base.GetComp<CompGlower>();
            this.powerTrader = base.GetComp<CompPowerTrader>();
            this.glowerColour = base.GetComp<CompGlowerColour>();

            this.Blackout = new ColorInt(100, 100, 100, 255);
            this.LedState = this.Blackout;
        }

        public override void Draw()
        {
            base.Draw();
            //changing the actual colour
            if (this.powerTrader.PowerOn)
            {
                if (this.LedState != this.activeColour())
                {
                    UpdateTex(this.activeColour());
                }
            }
            else
            {
                if (this.LedState != this.Blackout)
                {
                    UpdateTex(this.Blackout);
                }
            }

        }

        public override void Tick()
        {
            base.Tick();
            if (this.def.defName == "HRC_CeilingLamp")
            {
                if (!HasRoof)
                {
                    this.Destroy();
                }
            }
        }
        private bool HasRoof
        {
            get
            {
                int num = 0;
                int num2 = 0;
                foreach (IntVec3 current in this.OccupiedRect())
                {
                    num++;
                    //if (Find.RoofGrid.Roofed(current))
                    if (this.Map.roofGrid.Roofed(current))
                    {
                        num2++;
                    }
                }
                if (((float)(num - num2) / (float)num) < 1)
                {
                    return true;
                }
                return false;
            }
        }


        public override Color DrawColor
        {
            get
            {
                if (this.def.MadeFromStuff)
                {
                    return base.DrawColor;
                }
                return this.DrawColorTwo;
            }
        }

        //Changes the colour of the current led
        public override Color DrawColorTwo
        {
            get
            {
                return Util.IntToColour(LedState);
            }
        }

        #endregion

        #region simplifying
        //just to ease my eyes from the otherwise long string of text
        public ColorInt activeColour()
        {
            return ListOColours.colourList[this.glowerColour.ActiveColour].ColourValue;
        }

        private void UpdateTex(ColorInt col)
        {
            this.LedState = col;
            this.Notify_ColorChanged();
            Util.updateMap(base.Position,this.Map);
        }

        #endregion

    }
}

