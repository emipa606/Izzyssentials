﻿using System.Collections.Generic;
using Verse;
using RimWorld;
namespace Izzyssentials
{
    //works... stop touching it! 
    public class Building_PlantBetterGrower : Building_PlantGrower, IPlantToGrowSettable //  17/07/16-R
    {
        public override void SpawnSetup(Map map)
        {
            base.SpawnSetup(map);
            PlantDefChanger("inherit");
        }
        new public ThingDef GetPlantDefToGrow()
        {
            return base.GetPlantDefToGrow(); //this.plantDefToGrow
        }
        new public void SetPlantDefToGrow(ThingDef plantDef)
        {
            base.SetPlantDefToGrow(plantDef);//this.plantDefToGrow
            PlantDefChanger("spread");
        }

        // merged spread and inherit
        public void PlantDefChanger(string Command) // inherit or spread
        {
            IntVec3 q = new IntVec3(this.Position.x + 1, this.Position.y, this.Position.z + 0);
            IntVec3 r = new IntVec3(this.Position.x + 0, this.Position.y, this.Position.z + 1);
            IntVec3 s = new IntVec3(this.Position.x - 1, this.Position.y, this.Position.z + 0);
            IntVec3 t = new IntVec3(this.Position.x + 0, this.Position.y, this.Position.z - 1);
            IList<IntVec3> dirList = new List<IntVec3> { q, r, s, t };
         
            foreach (IntVec3 var in dirList)
            {
                List<Thing> list = var.GetThingList(this.Map);
                if (list != null)
                {
                    foreach (Thing curThing in list)
                    {
                        if (curThing is Building_PlantBetterGrower)
                        {
                            if (Command == "inherit" && ((Building_PlantBetterGrower)curThing).GetPlantDefToGrow() != base.GetPlantDefToGrow())
                            {
                                this.SetPlantDefToGrow(((Building_PlantBetterGrower)curThing).GetPlantDefToGrow());
                            }
                            if (Command == "spread" && ((Building_PlantBetterGrower)curThing).GetPlantDefToGrow() != base.GetPlantDefToGrow())
                            {
                                ((Building_PlantBetterGrower)curThing).SetPlantDefToGrow(base.GetPlantDefToGrow());
                            }
                        }
                    }
                }
            }
        }
    }
}
