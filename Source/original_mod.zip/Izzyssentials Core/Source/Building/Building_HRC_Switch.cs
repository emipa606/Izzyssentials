﻿using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Verse;
using Verse.Sound;
using RimWorld;

namespace Izzyssentials
{
    //Building, IFlickable => Iflickable changed to Comp
    public class Building_HRC_Switch : Building 
    {
        #region Variables
        //now in CompFlickable
        //private bool wantSwitchOn = true;
        //private bool switchOn = true;

        private bool switchOnOld = true;
        public CompFlickable flickableComp;//A13
        public CompSensor sensorComp;

        public ColorInt LedState;

        //now in CompFlickable
        //public bool SwitchOn 
        //{
        //    get
        //    {
        //        return this.switchOn;
        //    }

        //    set
        //    {
        //        if (value != this.switchOn)
        //        {
        //            this.switchOn = value;
        //            this.UpdatePowerGrid();
        //        }
        //    }
        //}

        public override bool TransmitsPowerNow
        {
            get
            {
                return this.flickableComp.SwitchIsOn;//A13
                //return this.switchOn;
            }
        }


        #endregion Variables


        public override void SpawnSetup(Map map)
        {
            base.SpawnSetup(map);
            this.flickableComp = base.GetComp<CompFlickable>();//A13
            this.sensorComp = base.GetComp<CompSensor>();
            this.LedState = ListOColours.Blackout;
        }

       

        public override void ExposeData()
        {
            base.ExposeData();
            //Scribe_Values.LookValue<bool>(ref this.switchOn, "switchOn", false, false);
            //Scribe_Values.LookValue<bool>(ref this.wantSwitchOn, "wantSwitchOn", false, false);
            //this.switchOnOld = !this.switchOn;
            //this.UpdatePowerGrid();
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (this.flickableComp == null)
                {
                    this.flickableComp = base.GetComp<CompFlickable>();
                }
                this.switchOnOld = !this.flickableComp.SwitchIsOn;
                this.UpdatePowerGrid();
            }
        }
        //moved to Comp
        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (var g in base.GetGizmos())
            {
                //Log.Message((typeof(Command_Toggle) != g.GetType()).ToString());
                if (typeof(Command_Toggle) != g.GetType())
                {
                    yield return g;
                }else
                {
                    if (!this.sensorComp.auto)
                    {
                        yield return g;
                    }
                }
            }
            yield break;
        }
       

        public override string GetInspectString() // fuck these comments to hell and back.
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append(base.GetInspectString());
            stringBuilder.AppendLine();
            stringBuilder.Append("PowerSwitch_Power".Translate() + ": ");
            if (this.flickableComp.SwitchIsOn)
            {
                stringBuilder.Append("On".Translate());
            }
            else
            {
                stringBuilder.Append("Off".Translate());
            }
            return stringBuilder.ToString();
        }

        protected override void ReceiveCompSignal(string signal)//A13
        {
            if (signal == "FlickedOff" || signal == "FlickedOn")
            {
                this.UpdatePowerGrid();
            }
        }

        private void UpdatePowerGrid()
        {
            
            if (this.flickableComp.SwitchIsOn != this.switchOnOld)
			{
                if (base.Spawned)
                {
                    base.Map.powerNetManager.Notfiy_TransmitterTransmitsPowerNowChanged(base.PowerComp);
                }
                this.switchOnOld = this.flickableComp.SwitchIsOn;
			}
          
        }

        public override void DrawExtraSelectionOverlays()
        {
                if (sensorComp != null)
                {
                if (sensorComp.auto)
                {
                    GenDraw.DrawRadiusRing(base.Position, sensorComp.setRadius);
                }
                   
                }
        }

        public override void Draw() // maybe cleanup this code? looks like a spider for some reason
        {
            base.Draw();
            if (this.flickableComp.SwitchIsOn)
            {
                if (base.PowerComp.PowerNet.CurrentEnergyGainRate() == 0)
                {
                    if (this.LedState != ListOColours.Red)
                    {
                        UpdateTex(ListOColours.Red);
                    }

                }
                else
                {
                    if (this.LedState != ListOColours.Green)
                    {
                        UpdateTex(ListOColours.Green);
                    }

                }
            }
            else
            {

                if (this.LedState != ListOColours.Blackout)
                {
                    UpdateTex(ListOColours.Blackout);
                }

            }

        }
        private void UpdateTex(ColorInt col)
        {
            this.LedState = col;
            this.Notify_ColorChanged();
            Util.updateMap(base.Position,this.Map);

        }
        public override Color DrawColor
        {
            get
            {
                if (this.def.MadeFromStuff)
                {
                    return base.DrawColor;
                }
                return this.DrawColorTwo;
            }
        }

        public override Color DrawColorTwo
        {
            get
            {
                return Util.IntToColour(LedState);
            }
        }
        
    }
}
