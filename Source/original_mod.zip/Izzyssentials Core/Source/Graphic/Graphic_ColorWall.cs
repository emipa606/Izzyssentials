﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;
namespace Izzyssentials
{
    public class Graphic_ColorWall : Graphic //17/07/16-R
    {

        //Graphic_collection
        protected Graphic[] subGraphics;


        //Graphic_Appearances
        public override Material MatSingle
        {
            get
            {
                return this.subGraphics[0].MatSingle;
            }
        }

        //Graphic_Appearances merged Graphic_collection
        public override void Init(GraphicRequest req)
        {

            if (req.path.NullOrEmpty())
            {
                throw new ArgumentNullException("folderPath");
            }
            if (req.shader == null)
            {
                throw new ArgumentNullException("shader");
            }

            this.path = req.path;
            this.color = req.color;
            this.colorTwo = req.colorTwo; //Multi
            this.drawSize = req.drawSize;

            List<Texture2D> list = ContentFinder<Texture2D>.GetAllInFolder(req.path).ToList<Texture2D>();
            
            if (list.NullOrEmpty<Texture2D>()) // Major graphic issues, had to
            {
                Log.Error("Collection cannot init: No textures found at path " + req.path);
                this.subGraphics = new Graphic[]
				{
					BaseContent.BadGraphic
				};
                return;
            }

            //gets every texture file into subGraphics
            this.subGraphics = new Graphic[list.Count / 2];
            int k = 0;
            for (int i = 0; i < list.Count; i++)
            {
                
                string path = req.path + "/" + list[i].name;
                if (!path.EndsWith("_m"))
                {
                    this.subGraphics[k] = GraphicDatabase.Get<Graphic_Single>(path,req.shader , this.drawSize, this.color, this.colorTwo) ; // this.shader
                    k++;
                }

            }

            //Copies every graphic in subgraphics into an array
            Graphic[] array = new Graphic[this.subGraphics.Length];
            for (int i = 0; i < this.subGraphics.Length; i++)
            {
                array[i] = this.subGraphics[i];
            }

            //resets subgraphics and makes it the lenght of stuffappearances
            this.subGraphics = new Graphic[Enum.GetNames(typeof(StuffAppearance)).Length];

            //Creates enu and gets all the values of StuffAppearance Smooth,Planks,Bricks
            IEnumerator enumerator = Enum.GetValues(typeof(StuffAppearance)).GetEnumerator();
            try
            {
                while (enumerator.MoveNext())
                {
                    StuffAppearance stuffAppearance = (StuffAppearance)((byte)enumerator.Current);
                    Graphic graphic = BaseContent.BadGraphic;

                    for (int j = 0; j < array.Length; j++)
                    {
                        Graphic graphic2 = array[j];
                        string[] array2 = graphic2.MatSingle.name.Split(new char[]
						{
							'_'
						});
                        string a = array2[array2.Length - 1];
                        if (a == stuffAppearance.ToString())
                        {
                            graphic = graphic2;
                            break;
                        }
                        if (graphic == null && a == StuffAppearance.Smooth.ToString())
                        {
                            graphic = graphic2;
                        }
                    }
                    //eventually picks wich type (Smooth,Planks,Bricks) needs to be picked.
                    this.subGraphics[(int)stuffAppearance] = graphic;

                }
            }
            finally
            {
                IDisposable disposable = enumerator as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
            }

        }
        //Graphic_Appearances
        public override Graphic GetColoredVersion(Shader newShader, Color newColor, Color newColorTwo)
        {

            return GraphicDatabase.Get<Graphic_ColorWall>(this.path, newShader, this.drawSize, newColor, newColorTwo);
        }
        //Graphic_Appearances
        public override Material MatSingleFor(Thing thing)
        {
            StuffAppearance stuffAppearance = StuffAppearance.Smooth;
            if (thing != null && thing.Stuff != null)
            {
                stuffAppearance = thing.Stuff.stuffProps.appearance;
            }
            Graphic graphic = this.subGraphics[(int)stuffAppearance];
            //graphic.ma
            return graphic.MatSingleFor(thing);
        }
        //Graphic_Appearances
        public override void DrawWorker(Vector3 loc, Rot4 rot, ThingDef thingDef, Thing thing)
        {
            StuffAppearance stuffAppearance = StuffAppearance.Smooth;
            if (thing != null && thing.Stuff != null)
            {
                stuffAppearance = thing.Stuff.stuffProps.appearance;
            }
            Graphic graphic = this.subGraphics[(int)stuffAppearance];
            graphic.DrawWorker(loc, rot, thingDef, thing);
        }
        //Graphic_Appearances
        public override string ToString()
        {
            return string.Concat(new object[]
			{
				"Appearance(path=",
				this.path,
				", color=",
				this.color,
				", colorTwo",
                this.colorTwo
			});
        }


    }
}
