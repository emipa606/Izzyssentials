﻿using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Verse;
using RimWorld;

namespace Izzyssentials
{
    public class CompSensor : ThingComp //17/07/16-R
    {
        public bool auto = false;
        public float maxRadius = 30f;
        public float setRadius = 10f;
        public string detectTarget = "friend";

      

        public override void PostSpawnSetup()
        {
            base.PostSpawnSetup();
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.LookValue<float>(ref this.setRadius, "setRadius",10f,true);
            Scribe_Values.LookValue<string>(ref this.detectTarget, "detectTarget","friend",true);
            Scribe_Values.LookValue<bool>(ref this.auto, "auto",false,true);
        }


        private CompPowerTrader GetParent_CompPowerTrader
        {
            get
            {
                return parent.TryGetComp<CompPowerTrader>();
            }
        }

        private CompFlickable GetParent_CompFlickable
        {
            get
            {
                return parent.TryGetComp<CompFlickable>();
            }
        }
        private IntVec3 GetParent_Pos
        {
            get
            {
                return parent.Position;
            }
        }


        //public IEnumerable<IntVec3> GrowableCells
        //{
        //    get
        //    {
        //        return GenRadial.RadialCellsAround(base.Position, this.def.specialDisplayRadius, true);
        //    }
        //}
        //[DebuggerHidden]
        //public override IEnumerable<Gizmo> GetGizmos()
        //{
        //    Building_SunLamp.< GetGizmos > c__Iterator11A < GetGizmos > c__Iterator11A = new Building_SunLamp.< GetGizmos > c__Iterator11A();

        //    < GetGizmos > c__Iterator11A.<> f__this = this;
        //    Building_SunLamp.< GetGizmos > c__Iterator11A expr_0E = < GetGizmos > c__Iterator11A;
        //    expr_0E.$PC = -2;
        //    return expr_0E;
        //}
        //private void MakeMatchingGrowZone()
        //{
        //    Designator_ZoneAdd_Growing designator = new Designator_ZoneAdd_Growing();
        //    designator.DesignateMultiCell(
        //        from tempCell in this.GrowableCells
        //        where designator.CanDesignateCell(tempCell).Accepted
        //        select tempCell);
        //}
        public override void CompTick()
        {
            if (Find.TickManager.TicksGame % 45 == 0)
            {
                if (auto && GetParent_CompFlickable != null)
                {
                    //if (Util.CheckPawnInRad(detectTarget,GetParent_Pos,this.setRadius))
                    //{
                    //    if (GetParent_CompFlickable.SwitchIsOn)
                    //        GetParent_CompFlickable.DoFlick();
                    //}else
                    //{
                    //    if (!GetParent_CompFlickable.SwitchIsOn)
                    //        GetParent_CompFlickable.DoFlick();
                    //}

                    List<Pawn> PinRadius = Util.RadiusPawns(detectTarget, GetParent_Pos,this.parent.Map ,this.setRadius);
                    //Log.Message(PinRadius.Count.ToString());
                    if (PinRadius.Count == 0)
                    {
                        if (GetParent_CompFlickable.SwitchIsOn)
                        {
                            GetParent_CompFlickable.DoFlick();
                        }

                    }
                    else
                    {
                        if (!GetParent_CompFlickable.SwitchIsOn)
                        {
                            GetParent_CompFlickable.DoFlick();
                        }
                    }
                }
            }
        }

        

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            IEnumerator<Gizmo> enumerator = base.CompGetGizmosExtra().GetEnumerator();
            while (enumerator.MoveNext())
            {
                Gizmo current = enumerator.Current;
                yield return current;
            }
            if (this.parent.Faction == Faction.OfPlayer)
            {
                if (DefDatabase<ResearchProjectDef>.GetNamed("Sensor").IsFinished)
                {
                    yield return this.Btn_Auto();
                    if (auto)
                    {
                        yield return this.Btn_Previous();
                        yield return this.Btn_Reset();
                        yield return this.Btn_Next();
                    }

                }
            }
            yield break;

        }
        public override string CompInspectStringExtra()
        {
            if (auto)
            {
                var stringBuilder = new StringBuilder();
                if (this.detectTarget == "friend")
                {
                    stringBuilder.Append("Currently targets colonists");
                }
                else
                {
                    stringBuilder.Append("Currently targets enemies");
                }
                stringBuilder.AppendLine();
                stringBuilder.Append("Current radius: " + this.setRadius.ToString());
                return stringBuilder.ToString();
            }
            return "";
        }

        public void Actionstart(int I_typeOfAction)
        {
            switch (I_typeOfAction)
            {
                case -1:

                    if (this.detectTarget == "friend")
                    {
                        this.detectTarget = "enemy";
                    }
                    else
                    {
                        this.detectTarget = "friend";
                    }
                    break;
                case 0:
                    if (this.setRadius != this.maxRadius)
                    {
                        this.setRadius = this.setRadius + 1f;
                    }
                    break;
                case 1:
                    if (this.setRadius != 1)
                    {
                        this.setRadius = this.setRadius - 1f;
                    }
                    break;
            }
        }
        public Command_Action Btn_Auto()
        {
            Command_Action command_Action = new Command_Action();
            command_Action.defaultLabel = "Function";
            if (this.auto)
            {
                command_Action.defaultDesc = "Change to manual";
                command_Action.icon = ContentFinder<Texture2D>.Get("UI/Commands/Switch/SensorRadar_A", true);
            }
            else
            {
                command_Action.defaultDesc = "Change to automatic";
                command_Action.icon = ContentFinder<Texture2D>.Get("UI/Commands/Switch/SensorRadar_M", true);
            }
            
            command_Action.action = delegate
            {
                //FloatMenuOption f = new FloatMenuOption();
                if (this.auto)
                {
                    this.auto = false;
                }
                else
                {
                    this.auto = true;
                }
                //FloatMenuOption floatMenuOption2 = new FloatMenuOption("TEST", null, MenuOptionPriority.High, null,null,0f,null) ;
                //List<FloatMenuOption> ff = new List<FloatMenuOption>();
                //ff.Add(floatMenuOption2);
                //FloatMenuMap floatMenuMap = new FloatMenuMap(ff, "title", Gen.MouseMapPosVector3());
                //floatMenuMap.givesColonistOrders = true;
                //Find.WindowStack.Add(floatMenuMap);
                
                //Find.WindowStack.Add(new FloatMenu(ff));

            };
            command_Action.activateSound = SoundDef.Named("Click");
            return command_Action;
        }



        public Command_Action Btn_Previous()
        {
            Command_Action command_Action = new Command_Action();
            command_Action.defaultLabel = "Target";
            command_Action.defaultDesc = "Change target";
            if (this.detectTarget == "friend")
            {
                command_Action.icon = ContentFinder<Texture2D>.Get("UI/Commands/Switch/SensorRadar_Friendly", true);
            }else
            {
                command_Action.icon = ContentFinder<Texture2D>.Get("UI/Commands/Switch/SensorRadar_Enemy", true);
            }
            command_Action.action = delegate
            {
                Actionstart(-1);
            };
            command_Action.activateSound = SoundDef.Named("Click");
            return command_Action;
        }
        public Command_Action Btn_Reset()
        {
            Command_Action command_Action = new Command_Action();
            command_Action.defaultLabel = "Radius+";
            command_Action.defaultDesc = "Make the detection radius bigger";
            //command_Action.icon = ContentFinder<Texture2D>.Get("UI/RotRight", true);
            command_Action.icon = ContentFinder<Texture2D>.Get("UI/Commands/Switch/SensorRadar_inc", true);
            command_Action.action = delegate
            {
                Actionstart(0);
            };
            command_Action.activateSound = SoundDef.Named("Click");
            return command_Action;
        }
        public Command_Action Btn_Next()
        {
            Command_Action command_Action = new Command_Action();
            command_Action.defaultLabel = "Radius-";
            command_Action.defaultDesc = "Make the detection radius smaller";
            //command_Action.icon = ContentFinder<Texture2D>.Get("UI/RotRight", true);
            command_Action.icon = ContentFinder<Texture2D>.Get("UI/Commands/Switch/SensorRadar_dec", true);
            command_Action.action = delegate
            {
                Actionstart(1);
            };
            command_Action.activateSound = SoundDef.Named("Click");
            return command_Action;
        }
        

    }

}

