﻿using System;
using UnityEngine;
using Verse;
using RimWorld;

namespace Izzyssentials
{
    public class CompPowerPlantSolarCon : CompPowerPlant //17/07/16-R
    {

        private float PowerOutputD
        {
            get
            {
                return Mathf.Lerp(0f, 100f, this.parent.Map.skyManager.CurSkyGlow);
            }
        }
        protected override float DesiredPowerOutput
        {
            get
            {
                return this.PowerOutputD * this.RoofedPowerOutputFactor;
            }
        }
        private float RoofedPowerOutputFactor
        {
            get
            {
                int num = 0;
                int num2 = 0;
                foreach (IntVec3 current in this.parent.OccupiedRect())
                {
                    num++;
                    if (this.parent.Map.roofGrid.Roofed(current))
                    {
                        num2++;
                    }
                }
                return (float)(num - num2) / (float)num;
            }
        }
        public override void PostDraw()
        {
     
            float f1 = this.PowerOutputD;

            base.PostDraw();
            DrawHelper.RectangleRequest r = default(DrawHelper.RectangleRequest);
            r.center = parent.DrawPos;
            r.size = new Vector2(0.16f, 0.16f);
            r.mat = SolidColorMaterials.SimpleSolidColorMaterial(new Color(
                ((115f - (f1 * 58f / 110f)) / 255f),
                ((130f - (f1 * 41f / 110f)) / 255f),
                ((140f - (f1 * 28f / 110f)) / 255f)
                ));
            r.rotation = parent.Rotation;
            DrawHelper.DrawRectangle(r);
        }
    }
}
