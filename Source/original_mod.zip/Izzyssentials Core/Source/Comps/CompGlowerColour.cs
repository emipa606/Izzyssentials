﻿using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Verse;
using RimWorld;

namespace Izzyssentials
{
    public class CompGlowerColour : ThingComp //17/07/16-R
    {
        


        public int ActiveColour;

        public CompGlower thisGlower;


        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.LookValue<int>(ref this.ActiveColour, "ActiveColour");
        }


        private CompPowerTrader GetParent_CompPowerTrader
        {
            get
            {
                return parent.TryGetComp<CompPowerTrader>();
            }
        }

        private CompGlower GetParent_CompGlower
        {
            get
            {
                return parent.TryGetComp<CompGlower>();
            }
        }



        public override void PostSpawnSetup()
        {
            base.PostSpawnSetup();
            ChangeColour();
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            IEnumerator<Gizmo> enumerator = base.CompGetGizmosExtra().GetEnumerator();
            while (enumerator.MoveNext())
            {
                Gizmo current = enumerator.Current;
                yield return current;
            }
            if (this.parent.Faction == Faction.OfPlayer)
            {
                if (DefDatabase<ResearchProjectDef>.GetNamed("ColoredLights").IsFinished)
                {
                    yield return this.Btn_Previous();
                    yield return this.Btn_Reset();
                    yield return this.Btn_Next();
                }
            }
            yield break;

        }
        public override string CompInspectStringExtra()
        {
            var stringBuilder = new StringBuilder();
            stringBuilder.Append("Current colour is : " + ListOColours.colourList[ActiveColour].colourName);
            return stringBuilder.ToString();
        }

        public void CycleColours_RetValue(int I_typeOfAction)
        {
            this.ActiveColour = GetColourIndex(I_typeOfAction);
        }
        public int GetColourIndex(int dirCounter)
        {
            int tempIndex = this.ActiveColour + dirCounter;
            if (dirCounter == 0 || tempIndex == ListOColours.colourList.Count)
                return 0;

            if (tempIndex == -1)
                return ListOColours.colourList.Count - 1;

            return tempIndex;
        }


        public void Actionstart(int I_typeOfAction)
        {
            CycleColours_RetValue(I_typeOfAction);
            ChangeColour();
        }

        public Command_Action Btn_Previous()
        {
            Command_Action command_Action = new Command_Action();
            command_Action.defaultLabel = "Previous colour";
            command_Action.defaultDesc = "Change light colour";
            string path = "UI/Commands/Lights/PT_left_" + GetColourIndex(-1).ToString();
            command_Action.icon = ContentFinder<Texture2D>.Get(path, true);
            command_Action.action = delegate
            {
                Actionstart(-1);
            };
            command_Action.activateSound = SoundDef.Named("Click");
            return command_Action;
        }
        public Command_Action Btn_Reset()
        {
            Command_Action command_Action = new Command_Action();
            command_Action.defaultLabel = "Reset";
            command_Action.defaultDesc = "Reset light colour";
            command_Action.icon = ContentFinder<Texture2D>.Get("UI/Commands/Lights/C_Reset", true);
            command_Action.action = delegate
            {
                Actionstart(0);
            };
            command_Action.activateSound = SoundDef.Named("Click");
            return command_Action;
        }
        public Command_Action Btn_Next()
        {
            Command_Action command_Action = new Command_Action();
            command_Action.defaultLabel = "Next Colour";
            command_Action.defaultDesc = "Change light colour";
            string path = "UI/Commands/Lights/PT_right_" + GetColourIndex(1).ToString();
            command_Action.icon = ContentFinder<Texture2D>.Get(path, true);
            command_Action.action = delegate
            {
                Actionstart(1);
            };
            command_Action.activateSound = SoundDef.Named("Click");
            return command_Action;
        }

        public void ChangeColour()
        {
            Util.DestroyNCreateGlower(this.parent, ListOColours.colourList[ActiveColour].ColourValue, 14f,this.parent.Map);//GetParent_CompGlower.props.glowRadius
            
        }




    }

}

